const savedRelatives = JSON.parse(localStorage.getItem('relatives') || '[]');

function login() {

  const username = document.getElementById("username").value;

  const password = document.getElementById("password").value;

  if (username === "Khelsingh" && password === "543575") {

    document.getElementById("login-section").classList.add("hidden");

    document.getElementById("main-section").classList.remove("hidden");

    renderRelatives();

  } else {

    alert("गलत यूजरनेम या पासवर्ड");

  }

}

function addRelative() {

  const name = document.getElementById("name").value;

  const village = document.getElementById("village").value;

  const relation = document.getElementById("relation").value;

  const photo = document.getElementById("photo").value;

  const newRelative = { name, village, relation, photo };

  savedRelatives.push(newRelative);

  localStorage.setItem('relatives', JSON.stringify(savedRelatives));

  renderRelatives();

  document.getElementById("name").value = "";

  document.getElementById("village").value = "";

  document.getElementById("relation").value = "";

  document.getElementById("photo").value = "";

}

function renderRelatives() {

  const container = document.getElementById("relatives-list");

  container.innerHTML = "";

  savedRelatives.forEach(rel => {

    const div = document.createElement("div");

    div.className = "card";

    div.innerHTML = `

      <strong>नाम:</strong> ${rel.name} <br/>

      <strong>गांव:</strong> ${rel.village} <br/>

      <strong>रिश्ता:</strong> ${rel.relation} <br/>

      ${rel.photo ? `<img src="${rel.photo}" alt="फोटो" />` : ""}

    `;

    container.appendChild(div);

  });

}